# setup.py

import setuptools

setuptools.setup(
    name="porty",
    version="0.0.1",
    author="netager",
    author_email="thinkjbank@gmail.com",
    description="Practical Python Code",
    packages=setuptools.find_packages(),
)